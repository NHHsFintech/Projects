﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KredittRater_NordTek
{
    class Class1
    {
        public string letter;
        public int res;
        public double CRP_value;
        public List<string> list_acc_figures = new List<string>() { "LG1_", "RDG_", "EKP_", "NDR_" };
        public List<string> match_letter = new List<string>() { "D", "C", "CC", "CCC", "B", "BB", "BBB", "A", "AA", "AAA" };
        public List<int> match_int = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        public double[,] array_accounting_figures = new double[4, 10] { { 0.3, 0.4, 0.5, 0.6, 0.9, 1.2, 1.7, 3, 6.2, 11.6 }, //5
                                                                        { -4.1, -1.58, -0.76, 0.07, 0.9, 1.22, 2.16, 3.35, 6.3, 16.9 }, 
                                                                        { 1.8, 2, 8, 13, 22, 32, 44, 66, 85, 94 }, 
                                                                        { -7.2, -4.4, -1.6, 1.2, 4, 6.8, 9.6, 16.6, 26.6, 35 } };
        public List<double> list_CRP = new List<double>() { 0.28, 0.214, 0.149, 0.083, 0.044, 0.031, 0.014, 0.010, 0.008, 0.006 };
        
        //2: 7 + 6 + 2 + 4 = 4,75 CCC
        //5: 8 + 8 + 2 + 5 = 5,75 B


        public Class1() //Constructor
        {

        }

        public List<double> rating(double[] Accounting_figure)
        {
            List<double> myList = new List<double>();
            
            for (int i = 0; i < array_accounting_figures.GetLength(0); i++)
            { 
                int xx = 1;
                for (int j = 0; j < array_accounting_figures.GetLength(1); j++)
                {
                    xx++;
                    if (Accounting_figure[i] < array_accounting_figures[i, j])
                    {
                        //res += xx;
                        //myList.Add(xx);
                        myList.Add(match_int[j-1]);//array_accounting_figures[i, j - 1]
                        break;
                    }
                    else
                    {
                        continue;
                    }
                    /*else
                    {
                        myList.Add(xx);//array_accounting_figures[i, j - 1]
                        break;
                    }*/
                }
            }
            return myList;
        }

        public double KredittRate_(double[] array_of_input)
        {         
            double l = 0;
            l = rating(array_of_input).Sum() / array_accounting_figures.GetLength(0);
            return l;          
        }

        public string converter(double result_kredittRate)
        {
            
            for (int i = 0; i < match_int.Count; i++)
            {
                if(result_kredittRate <= match_int[i])
                {
                    letter = match_letter[i-1];
                    break;
                }
                else
                {
                    continue;
                }
            }




            /*if(result_kredittRate < 0)
            {
               
            }
            int indeks = 0;
            while (result_kredittRate > indeks)
            {
                indeks++;
            }*/
            return letter;
        }

        public double syntethic_Kredit_risk_premium_(double[] array_of_input) //syntethic credit risk premium
        {
            string final_rating = converter(KredittRate_(array_of_input)); //gir oss bokstav 
            for (int i = 0; i <= list_CRP.Count; i++)
            {
                if (final_rating == match_letter[i])
                {
                    CRP_value = list_CRP[i];
                    break;
                }
                else
                {
                    continue;
                }      
            }
            return CRP_value;
        }



        public double prob_bankruptcy(double CRP_value_) 
        {
            double prob_bankruptcy_result = Math.Round((CRP_value_ / list_CRP[0])*100, 2);
            return prob_bankruptcy_result;
        }
    }
}

