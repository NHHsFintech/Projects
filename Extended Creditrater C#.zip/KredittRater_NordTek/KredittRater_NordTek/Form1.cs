﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KredittRater_NordTek
{
    public partial class Form1 : Form
    {
        public double LG1_, RDG_, EKP_, NDR_;
        Class1 regnut = new Class1();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //KreditRating result
            double LG1_ = Convert.ToDouble(textBox1.Text);
            double RDG_ = Convert.ToDouble(textBox2.Text);
            double EKP_ = Convert.ToDouble(textBox3.Text);
            double NDR_ = Convert.ToDouble(textBox4.Text);
            double[] array_accounting_figures = new double[] { LG1_, RDG_, EKP_, NDR_ };

            textBox5.Text = regnut.converter(regnut.KredittRate_(array_accounting_figures)).ToString(); //syntethic credit rating
            double credit_risk_premium = regnut.syntethic_Kredit_risk_premium_(array_accounting_figures);
            textBox6.Text = credit_risk_premium.ToString(); //Credit risk premium
            textBox7.Text = regnut.prob_bankruptcy(credit_risk_premium).ToString() + "%";
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            //Kredit risk premium



        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            //LG1
            
        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {
            //Syntethic credit rating
        }

        private void TextBox6_TextChanged(object sender, EventArgs e)
        {
            //Credit risk premium
        }

        private void TextBox7_TextChanged(object sender, EventArgs e)
        {
            //Probability of bankruptcy
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            //RDG
            
        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {
            //EKP
            
        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {
            //NDR
            
        }
    }
}
